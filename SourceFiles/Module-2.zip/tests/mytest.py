import minitorch

import minitorch.tensor as tensor


#a = tensor([[1,2],[1,2]])
#b = tensor([[3,3],[4,4]])
a = tensor([1,2])
b = tensor([[3],[4]])
c = a * b
print(c)
c = c.sum()
print(c)
c.backward()

order = [2,0,1]
un_permute = [0 for _ in range(len(order))]
print(un_permute)

for d1, d2 in enumerate(order):
    un_permute[d2] = d1
print(un_permute)

""""""





